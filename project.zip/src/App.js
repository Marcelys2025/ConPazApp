import React, { useState, useCallback } from 'react';
import AuthLogin from './components/AuthLogin';
import StudentDashboard from './components/StudentDashboard';
import TeacherDashboard from './components/TeacherDashboard';
import SurveyForm from './components/SurveyForm';
import VideoResourcesPage from './components/VideoResourcesPage';
import InteractiveEnvironment from './components/InteractiveEnvironment';
import ChatbotAssistant from './components/ChatbotAssistant';
import ActivitiesPage from './components/ActivitiesPage';
import TrainingModule from './components/TrainingModule';
import ReportForm from './components/ReportForm';
import ReportsListPage from './components/ReportsListPage';
import InitialMenu from './components/InitialMenu';
import ForumPage from './components/ForumPage';
import GamesPage from './components/GamesPage';
import ResourcesPage from './components/ResourcesPage'; // Importar el nuevo componente

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userType, setUserType] = useState(null); // 'student' or 'teacher'
  const [username, setUsername] = useState('');
  const [currentView, setCurrentView] = useState('initialMenu'); // Estado inicial: el nuevo menú
  const [surveyCompleted, setSurveyCompleted] = useState(false);
  const [trainingProgress, setTrainingProgress] = useState({});
  const [conflictReports, setConflictReports] = useState([]); // Nuevo estado para almacenar reportes
  const [activities, setActivities] = useState([ // Estado para almacenar actividades
    {
      id: 'a1',
      title: 'Taller de Comunicación Asertiva',
      description: 'Aprende a expresar tus ideas y sentimientos de forma clara y respetuosa.',
      type: 'Taller',
      date: '2024-05-15',
      for: ['student', 'teacher'],
    },
    {
      id: 'a2',
      title: 'Juego de Roles: Resolviendo Conflictos',
      description: 'Participa en escenarios simulados para practicar la resolución de problemas.',
      type: 'Juego',
      date: '2024-05-20',
      for: ['student'],
    },
  ]);

  const handleLogin = (type, name) => {
    setUserType(type);
    setUsername(name);
    setIsLoggedIn(true);
    setCurrentView('dashboard'); // Al iniciar sesión, ir al dashboard
    // Cargar progreso guardado para el usuario (simulado)
    setTrainingProgress(JSON.parse(localStorage.getItem(`trainingProgress_${name}_${type}`)) || {});
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserType(null);
    setUsername('');
    setCurrentView('initialMenu'); // Volver al menú inicial al cerrar sesión
    setSurveyCompleted(false);
    setTrainingProgress({}); // Limpiar progreso al cerrar sesión
  };

  const handleSurveySubmit = (surveyData) => {
    console.log('Encuesta enviada:', surveyData);
    setSurveyCompleted(true);
    setCurrentView('dashboard'); // Volver al dashboard después de la encuesta
    alert('¡Gracias por completar la encuesta!');
  };

  // Función para guardar el progreso del módulo
  const saveTrainingProgress = useCallback((progress) => {
    setTrainingProgress(progress);
    localStorage.setItem(`trainingProgress_${username}_${userType}`, JSON.stringify(progress));
  }, [username, userType]);

  // Función para manejar el envío de reportes
  const handleReportSubmit = (reportData) => {
    const newReport = {
      id: conflictReports.length + 1, // ID simple para el seguimiento
      ...reportData,
      reporter: reportData.anonymous ? 'Anónimo' : username,
      date: new Date().toLocaleDateString(),
      status: 'Pendiente', // Estado inicial del reporte
    };
    setConflictReports((prevReports) => [...prevReports, newReport]);
    setCurrentView('dashboard'); // Volver al dashboard después de enviar el reporte
    alert('¡Reporte enviado con éxito! Gracias por tu contribución.');
  };

  // Función para actualizar el estado de un reporte
  const handleUpdateReportStatus = (reportId, newStatus) => {
    setConflictReports((prevReports) =>
      prevReports.map((report) =>
        report.id === reportId ? { ...report, status: newStatus } : report
      )
    );
    alert(`Estado del reporte ${reportId} actualizado a: ${newStatus}`);
  };

  // Funciones para gestionar actividades
  const handleAddActivity = (newActivity) => {
    setActivities((prevActivities) => [...prevActivities, newActivity]);
    alert('Actividad creada con éxito!');
  };

  const handleUpdateActivity = (updatedActivity) => {
    setActivities((prevActivities) =>
      prevActivities.map((activity) =>
        activity.id === updatedActivity.id ? updatedActivity : activity
      )
    );
    alert('Actividad actualizada con éxito!');
  };

  const handleDeleteActivity = (activityId) => {
    setActivities((prevActivities) => prevActivities.filter((activity) => activity.id !== activityId));
    alert('Actividad eliminada con éxito!');
  };

  const handleSelectRoleFromMenu = (role) => {
    setCurrentView('login');
    setUserType(role);
  };

  const renderContent = () => {
    if (currentView === 'initialMenu') {
      return <InitialMenu onSelectRole={handleSelectRoleFromMenu} onNavigate={setCurrentView} />;
    }

    if (currentView === 'login') {
      return <AuthLogin onLogin={handleLogin} initialUserType={userType} />;
    }

    // Si la encuesta no está completada, forzar la vista de encuesta
    if (!surveyCompleted && isLoggedIn) {
      return <SurveyForm userType={userType} onSubmitSurvey={handleSurveySubmit} />;
    }

    // Renderizar la vista actual según el estado
    switch (currentView) {
      case 'dashboard':
        if (userType === 'student') {
          return (
            <StudentDashboard
              username={username}
              onLogout={handleLogout}
              onNavigate={setCurrentView}
              currentView={currentView}
            />
          );
        } else if (userType === 'teacher') {
          return (
            <TeacherDashboard
              username={username}
              onLogout={handleLogout}
              onNavigate={setCurrentView}
              currentView={currentView}
            />
          );
        }
        break;
      case 'activities':
        return (
          <ActivitiesPage
            userType={userType}
            onBack={() => setCurrentView('dashboard')}
            activities={activities}
            onAddActivity={handleAddActivity}
            onUpdateActivity={handleUpdateActivity}
            onDeleteActivity={handleDeleteActivity}
          />
        );
      case 'videos': // Esta vista ya no se usa directamente, ahora se accede a través de ResourcesPage
        return <VideoResourcesPage userType={userType} onBack={() => setCurrentView('dashboard')} />;
      case 'interactive':
        const currentUser = {
          name: username,
          userType: userType,
          avatarUrl: userType === 'student' ? 'https://randomuser.me/api/portraits/men/5.jpg' : 'https://randomuser.me/api/portraits/women/6.jpg',
        };
        return <InteractiveEnvironment currentUser={currentUser} onBack={() => setCurrentView('dashboard')} />;
      case 'training':
        return (
          <TrainingModule
            userType={userType}
            onBack={() => setCurrentView('dashboard')}
            onSaveProgress={saveTrainingProgress}
            savedProgress={trainingProgress}
          />
        );
      case 'survey':
        return <SurveyForm userType={userType} onSubmitSurvey={handleSurveySubmit} />;
      case 'reportForm':
        return <ReportForm onSubmitReport={handleReportSubmit} onBack={() => setCurrentView('dashboard')} />;
      case 'reportsList':
        return <ReportsListPage reports={conflictReports} onBack={() => setCurrentView('dashboard')} onUpdateReportStatus={handleUpdateReportStatus} />;
      case 'chatbot':
        return <ChatbotAssistant onClose={() => setCurrentView('dashboard')} />;
      case 'forum':
        const forumUser = {
          name: username,
          userType: userType,
        };
        return <ForumPage onBack={() => setCurrentView('dashboard')} currentUser={forumUser} />;
      case 'games':
        return <GamesPage onBack={() => setCurrentView('dashboard')} userCreatedGames={[]} onCreateGame={() => {}} />; // Pasar props vacías por ahora
      case 'resources': // Nueva vista para la página de Recursos
        return <ResourcesPage userType={userType} onBack={() => setCurrentView('dashboard')} />;
      case 'peaceAgreements': // Nueva vista para Acuerdos de Paz (placeholder)
        return (
          <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-yellow-50 to-orange-100 p-4">
            <div className="bg-white p-8 rounded-3xl shadow-2xl text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Acuerdos de Paz</h2>
              <p className="text-gray-700 mb-6">Aquí encontrarás información sobre acuerdos de paz y reconciliación.</p>
              <button
                onClick={() => setCurrentView('dashboard')}
                className="px-6 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
              >
                Volver al Inicio
              </button>
            </div>
          </div>
        );
      default:
        return <p>Vista no encontrada</p>;
    }
    return null;
  };

  return (
    <div className="min-h-screen font-sans antialiased">
      {renderContent()}
      {isLoggedIn && currentView !== 'chatbot' && (
        <button
          onClick={() => setCurrentView('chatbot')}
          className="fixed bottom-4 right-4 bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition-colors z-50"
        >
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path>
          </svg>
        </button>
      )}
    </div>
  );
}

export default App;
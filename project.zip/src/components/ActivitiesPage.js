import React, { useState } from 'react';
import ActivityCard from './ActivityCard';
import ActivityForm from './ActivityForm'; // Importar el formulario de actividad

const ActivitiesPage = ({ userType, onBack, activities, onAddActivity, onUpdateActivity, onDeleteActivity }) => {
  const [showActivityForm, setShowActivityForm] = useState(false);
  const [editingActivity, setEditingActivity] = useState(null); // Para guardar la actividad que se está editando

  const handleAddClick = () => {
    setEditingActivity(null); // Asegurarse de que es una nueva actividad
    setShowActivityForm(true);
  };

  const handleEditClick = (activity) => {
    setEditingActivity(activity);
    setShowActivityForm(true);
  };

  const handleDeleteClick = (activityId) => {
    if (window.confirm('¿Estás seguro de que quieres eliminar esta actividad?')) {
      onDeleteActivity(activityId);
    }
  };

  const handleSubmitActivity = (activityData) => {
    if (editingActivity) {
      onUpdateActivity(activityData);
    } else {
      onAddActivity(activityData);
    }
    setShowActivityForm(false);
    setEditingActivity(null);
  };

  if (showActivityForm) {
    return <ActivityForm onSubmitActivity={handleSubmitActivity} onBack={() => setShowActivityForm(false)} initialData={editingActivity} />;
  }

  // Filtrar actividades según el tipo de usuario
  const filteredActivities = activities.filter(activity => activity.for.includes(userType));

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4 sm:p-8">
      <div className="max-w-6xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Actividades de Convivencia
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver
          </button>
        </div>

        {userType === 'teacher' && (
          <div className="mb-8 p-6 bg-blue-50 rounded-2xl border border-blue-200 shadow-md">
            <h3 className="text-xl font-semibold text-blue-800 mb-3">Gestionar Actividades</h3>
            <p className="text-gray-700 mb-4">Aquí podrás añadir, editar o eliminar actividades para los estudiantes.</p>
            <button
              onClick={handleAddClick}
              className="px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors"
            >
              Añadir Nueva Actividad
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredActivities.length > 0 ? (
            filteredActivities.map((activity) => (
              <div key={activity.id} className="relative">
                <ActivityCard
                  title={activity.title}
                  description={activity.description}
                  type={activity.type}
                  date={activity.date}
                />
                {userType === 'teacher' && (
                  <div className="absolute top-3 right-3 flex space-x-2">
                    <button
                      onClick={() => handleEditClick(activity)}
                      className="p-2 bg-yellow-500 text-white rounded-full hover:bg-yellow-600 transition-colors"
                      title="Editar"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                    </button>
                    <button
                      onClick={() => handleDeleteClick(activity.id)}
                      className="p-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
                      title="Eliminar"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    </button>
                  </div>
                )}
              </div>
            ))
          ) : (
            <p className="col-span-full text-center text-gray-600 text-lg mt-10">
              No hay actividades disponibles para tu perfil en este momento.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ActivitiesPage;
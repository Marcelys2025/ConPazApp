import React from 'react';

const ActivityCard = ({ title, description, type, date }) => {
  const typeColors = {
    'Dinámica de Grupo': 'bg-blue-100 text-blue-800 border-blue-200',
    'Taller': 'bg-green-100 text-green-800 border-green-200',
    'Juego': 'bg-purple-100 text-purple-800 border-purple-200',
    'Charla': 'bg-yellow-100 text-yellow-800 border-yellow-200',
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200 transform transition-all duration-300 hover:scale-105 hover:shadow-xl">
      <div className="p-6">
        <span className={`inline-block px-3 py-1 text-xs font-semibold rounded-full ${typeColors[type] || 'bg-gray-100 text-gray-800 border-gray-200'} mb-3`}>
          {type}
        </span>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-700 text-sm mb-4">{description}</p>
        <div className="flex justify-between items-center text-gray-500 text-xs">
          <span>Fecha: {date}</span>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors">
            Ver Detalles
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActivityCard;
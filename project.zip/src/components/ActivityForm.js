import React, { useState } from 'react';

const ActivityForm = ({ onSubmitActivity, onBack, initialData = {} }) => {
  const [title, setTitle] = useState(initialData.title || '');
  const [description, setDescription] = useState(initialData.description || '');
  const [type, setType] = useState(initialData.type || 'Dinámica de Grupo');
  const [date, setDate] = useState(initialData.date || '');
  const [forStudents, setForStudents] = useState(initialData.for?.includes('student') || true);
  const [forTeachers, setForTeachers] = useState(initialData.for?.includes('teacher') || false);

  const activityTypes = ['Dinámica de Grupo', 'Taller', 'Juego', 'Charla', 'Otro'];

  const handleSubmit = () => {
    if (title && description && date && (forStudents || forTeachers)) {
      const audience = [];
      if (forStudents) audience.push('student');
      if (forTeachers) audience.push('teacher');

      onSubmitActivity({
        id: initialData.id || Date.now().toString(), // Generar ID si es nuevo
        title,
        description,
        type,
        date,
        for: audience,
      });
    } else {
      alert('Por favor, completa todos los campos y selecciona al menos un tipo de usuario.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-100 p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl w-full max-w-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">
            {initialData.id ? 'Editar Actividad' : 'Crear Nueva Actividad'}
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver
          </button>
        </div>

        <div className="mb-6">
          <label htmlFor="title" className="block text-gray-700 text-lg font-semibold mb-2">
            Título de la Actividad
          </label>
          <input
            type="text"
            id="title"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
            placeholder="Ej: Taller de Empatía"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        <div className="mb-6">
          <label htmlFor="description" className="block text-gray-700 text-lg font-semibold mb-2">
            Descripción
          </label>
          <textarea
            id="description"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 resize-none"
            rows="4"
            placeholder="Describe en qué consiste la actividad y sus objetivos."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          ></textarea>
        </div>

        <div className="mb-6">
          <label htmlFor="type" className="block text-gray-700 text-lg font-semibold mb-2">
            Tipo de Actividad
          </label>
          <select
            id="type"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 bg-white"
            value={type}
            onChange={(e) => setType(e.target.value)}
          >
            {activityTypes.map(actType => (
              <option key={actType} value={actType}>{actType}</option>
            ))}
          </select>
        </div>

        <div className="mb-6">
          <label htmlFor="date" className="block text-gray-700 text-lg font-semibold mb-2">
            Fecha de la Actividad
          </label>
          <input
            type="date"
            id="date"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 bg-white"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>

        <div className="mb-8">
          <label className="block text-gray-700 text-lg font-semibold mb-2">
            Dirigido a:
          </label>
          <div className="flex space-x-4">
            <label className="inline-flex items-center">
              <input
                type="checkbox"
                className="form-checkbox h-5 w-5 text-blue-600"
                checked={forStudents}
                onChange={(e) => setForStudents(e.target.checked)}
              />
              <span className="ml-2 text-gray-800">Estudiantes</span>
            </label>
            <label className="inline-flex items-center">
              <input
                type="checkbox"
                className="form-checkbox h-5 w-5 text-blue-600"
                checked={forTeachers}
                onChange={(e) => setForTeachers(e.target.checked)}
              />
              <span className="ml-2 text-gray-800">Docentes</span>
            </label>
          </div>
        </div>

        <button
          onClick={handleSubmit}
          className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-blue-700 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105"
        >
          {initialData.id ? 'Guardar Cambios' : 'Crear Actividad'}
        </button>
      </div>
    </div>
  );
};

export default ActivityForm;
import React from 'react';

const AppLogo = () => {
  return (
    <div className="flex items-center justify-center space-x-2">
      {/* Logo personalizado */}
      <img
        src="https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0rGRZeOBNQiYtyo2GFJjxB80HOpNwcWZhvnAD"
        alt="ConPazApp Logo"
        className="w-24 h-24 object-contain"
      />
      <span className="text-4xl font-extrabold text-gray-900">ConPazApp</span>
    </div>
  );
};

export default AppLogo;
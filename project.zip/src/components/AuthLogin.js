import React, { useState } from 'react';
import AppLogo from './AppLogo'; // Importar el logo

const AuthLogin = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [userType, setUserType] = useState('student'); // 'student' or 'teacher'

  const handleLogin = () => {
    if (username && password) {
      onLogin(userType, username);
    } else {
      alert('Por favor, ingresa tu usuario y contraseña.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-200 via-purple-200 to-pink-200 p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl w-full max-w-md border border-gray-200">
        <div className="mb-8 flex justify-center">
          <AppLogo />
        </div>
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
          Inicia Sesión
        </h2>
        <div className="mb-6">
          <label htmlFor="username" className="block text-gray-700 text-sm font-semibold mb-2">
            Usuario
          </label>
          <input
            type="text"
            id="username"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
            placeholder="Tu nombre de usuario"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="mb-6">
          <label htmlFor="password" className="block text-gray-700 text-sm font-semibold mb-2">
            Contraseña
          </label>
          <input
            type="password"
            id="password"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
            placeholder="Tu contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div className="mb-8">
          <label className="block text-gray-700 text-sm font-semibold mb-2">
            Tipo de Usuario
          </label>
          <div className="flex space-x-4">
            <label className="inline-flex items-center">
              <input
                type="radio"
                className="form-radio h-5 w-5 text-blue-600"
                name="userType"
                value="student"
                checked={userType === 'student'}
                onChange={() => setUserType('student')}
              />
              <span className="ml-2 text-gray-800">Estudiante</span>
            </label>
            <label className="inline-flex items-center">
              <input
                type="radio"
                className="form-radio h-5 w-5 text-blue-600"
                name="userType"
                value="teacher"
                checked={userType === 'teacher'}
                onChange={() => setUserType('teacher')}
              />
              <span className="ml-2 text-gray-800">Docente</span>
            </label>
          </div>
        </div>
        <button
          onClick={handleLogin}
          className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-blue-700 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105"
        >
          Iniciar Sesión
        </button>
      </div>
    </div>
  );
};

export default AuthLogin;
import React from 'react';

const AvatarDisplay = ({ avatarUrl, name, userType }) => {
  const borderColor = userType === 'student' ? 'border-blue-500' : 'border-purple-500';
  const bgColor = userType === 'student' ? 'bg-blue-100' : 'bg-purple-100';
  const textColor = userType === 'student' ? 'text-blue-800' : 'text-purple-800';

  return (
    <div className={`flex flex-col items-center p-2 rounded-xl ${bgColor} border-2 ${borderColor} shadow-md`}>
      <img
        src={avatarUrl || 'https://via.placeholder.com/60/F3F4F6/9CA3AF?text=AV'} // Placeholder si no hay URL
        alt={`${name}'s avatar`}
        className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-sm"
      />
      <span className={`mt-2 text-sm font-semibold ${textColor}`}>
        {name}
      </span>
    </div>
  );
};

export default AvatarDisplay;
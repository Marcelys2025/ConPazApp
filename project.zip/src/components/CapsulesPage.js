import React, { useState } from 'react';

const CapsulesPage = ({ userType, onBack }) => {
  const [selectedCapsule, setSelectedCapsule] = useState(null);

  // Datos de ejemplo de cápsulas formativas
  const capsules = [
    {
      id: 'c1',
      title: 'La Escucha Activa en 5 Pasos',
      description: 'Aprende a escuchar de verdad para mejorar tus relaciones.',
      content: `
        <h3 class="text-xl font-semibold text-gray-900 mb-3">¿Qué es la Escucha Activa?</h3>
        <p class="text-gray-700 mb-4">Es una habilidad fundamental que implica prestar atención plena a lo que la otra persona dice, tanto verbal como no verbalmente, y demostrar que la estás entendiendo.</p>
        <h4 class="text-lg font-semibold text-gray-800 mb-2">5 Pasos Clave:</h4>
        <ol class="list-decimal list-inside text-gray-700 space-y-2 mb-4">
          <li>Presta atención: Deja de lado distracciones y concéntrate en el hablante.</li>
          <li>No interrumpas: Permite que la persona termine su idea antes de hablar.</li>
          <li>Haz preguntas: Para clarificar y mostrar interés.</li>
          <li>Parafrasea: Repite con tus propias palabras lo que entendiste para confirmar.</li>
          <li>Observa el lenguaje no verbal: Gestos, postura, tono de voz.</li>
        </ol>
        <p class="text-gray-700 italic">¡Practica estos pasos y verás cómo mejora tu comunicación!</p>
      `,
      for: ['student', 'teacher'],
    },
    {
      id: 'c2',
      title: 'Manejo de Emociones Fuertes',
      description: 'Herramientas para identificar y gestionar tus emociones de forma saludable.',
      content: `
        <h3 class="text-xl font-semibold text-gray-900 mb-3">Identifica tus Emociones</h3>
        <p class="text-gray-700 mb-4">El primer paso es reconocer qué emoción estás sintiendo (ira, tristeza, frustración, etc.).</p>
        <h4 class="text-lg font-semibold text-gray-800 mb-2">Técnicas de Regulación:</h4>
        <ul class="list-disc list-inside text-gray-700 space-y-2 mb-4">
          <li>Respiración profunda: Inhala lentamente por la nariz, retén, exhala por la boca.</li>
          <li>Pausa y reflexión: Antes de reaccionar, tómate un momento para pensar.</li>
          <li>Expresión saludable: Habla de tus emociones con alguien de confianza o escríbelas.</li>
          <li>Actividad física: Libera tensión con ejercicio o movimiento.</li>
        </ul>
        <p class="text-gray-700 italic">Recuerda que sentir emociones es normal, lo importante es cómo las manejas.</p>
      `,
      for: ['student'],
    },
    {
      id: 'c3',
      title: 'Resolución de Conflictos: Gana-Gana',
      description: 'Aprende a buscar soluciones donde todas las partes se beneficien.',
      content: `
        <h3 class="text-xl font-semibold text-gray-900 mb-3">Enfoque Gana-Gana</h3>
        <p class="text-gray-700 mb-4">En la resolución de conflictos, el objetivo no es que uno gane y el otro pierda, sino encontrar una solución que satisfaga las necesidades de todos los involucrados.</p>
        <h4 class="text-lg font-semibold text-gray-800 mb-2">Pasos para una Solución Gana-Gana:</h4>
        <ol class="list-decimal list-inside text-gray-700 space-y-2 mb-4">
          <li>Define el problema: Claramente y sin culpar.</li>
          <li>Identifica intereses: ¿Qué necesita cada parte?</li>
          <li>Genera opciones: Piensen en muchas soluciones posibles.</li>
          <li>Evalúa opciones: ¿Cuáles satisfacen más intereses?</li>
          <li>Elige la mejor solución: Aquella que todos puedan aceptar.</li>
        </ol>
        <p class="text-gray-700 italic">¡La colaboración es la clave para la paz!</p>
      `,
      for: ['teacher'],
    },
  ];

  const filteredCapsules = capsules.filter(capsule => capsule.for.includes(userType));

  if (selectedCapsule) {
    return (
      <div className="p-6 bg-white rounded-2xl shadow-md border border-gray-200">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900">{selectedCapsule.title}</h3>
          <button
            onClick={() => setSelectedCapsule(null)}
            className="px-4 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver a Cápsulas
          </button>
        </div>
        <div
          className="prose max-w-none text-gray-700 leading-relaxed"
          dangerouslySetInnerHTML={{ __html: selectedCapsule.content }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Cápsulas Formativas
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCapsules.length > 0 ? (
            filteredCapsules.map((capsule) => (
              <div key={capsule.id} className="bg-yellow-50 p-6 rounded-2xl shadow-md border border-yellow-200 transform transition-all duration-300 hover:scale-105 hover:shadow-xl">
                <h3 className="text-xl font-semibold text-yellow-800 mb-3">{capsule.title}</h3>
                <p className="text-gray-700 mb-4">{capsule.description}</p>
                <button
                  onClick={() => setSelectedCapsule(capsule)}
                  className="px-6 py-2 bg-yellow-600 text-white rounded-xl hover:bg-yellow-700 transition-colors"
                >
                  Leer Cápsula
                </button>
              </div>
            ))
          ) : (
            <p className="col-span-full text-center text-gray-600 text-lg mt-10">
              No hay cápsulas formativas disponibles para tu perfil en este momento.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default CapsulesPage;
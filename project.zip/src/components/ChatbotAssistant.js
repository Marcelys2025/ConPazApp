import React, { useState, useEffect, useRef } from 'react';

const ChatbotAssistant = ({ onClose }) => {
  const [messages, setMessages] = useState([
    { id: 1, sender: 'bot', text: '¡Hola! Soy tu asistente de ConPazApp. ¿En qué puedo ayudarte hoy?', timestamp: new Date().toLocaleTimeString() }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (inputMessage.trim()) {
      const userMessage = { id: messages.length + 1, sender: 'user', text: inputMessage.trim(), timestamp: new Date().toLocaleTimeString() };
      setMessages((prevMessages) => [...prevMessages, userMessage]);
      setInputMessage('');

      // Simular respuesta del bot
      setTimeout(() => {
        const botResponse = getBotResponse(userMessage.text);
        setMessages((prevMessages) => [...prevMessages, { id: prevMessages.length + 1, sender: 'bot', text: botResponse, timestamp: new Date().toLocaleTimeString() }]);
      }, 1000);
    }
  };

  const getBotResponse = (message) => {
    const lowerCaseMessage = message.toLowerCase();
    if (lowerCaseMessage.includes('hola') || lowerCaseMessage.includes('saludo')) {
      return '¡Hola! ¿Cómo estás? Me alegra que estés aquí.';
    } else if (lowerCaseMessage.includes('convivencia')) {
      return 'La convivencia escolar es fundamental para un ambiente de aprendizaje positivo. ¿Te gustaría saber más sobre cómo mejorarla?';
    } else if (lowerCaseMessage.includes('reportar')) {
      return 'Si necesitas reportar una situación, puedes hacerlo desde tu panel principal. Busca la opción "Reportar Situación".';
    } else if (lowerCaseMessage.includes('videos') || lowerCaseMessage.includes('recursos')) {
      return 'Tenemos una sección de recursos de video muy útil. Puedes encontrarla en tu panel principal bajo "Recursos de Video".';
    } else if (lowerCaseMessage.includes('encuesta')) {
      return 'La encuesta de entrada nos ayuda a entender mejor tus necesidades. Si aún no la has completado, te invito a hacerlo desde tu panel.';
    } else if (lowerCaseMessage.includes('gracias')) {
      return 'De nada, ¡estoy para servirte!';
    } else if (lowerCaseMessage.includes('adiós') || lowerCaseMessage.includes('chao')) {
      return '¡Hasta pronto! Que tengas un excelente día.';
    } else {
      return 'Hmm, no estoy seguro de cómo ayudarte con eso. ¿Podrías reformular tu pregunta o intentar con otro tema?';
    }
  };

  return (
    <div className="fixed bottom-4 right-4 w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col z-50">
      <div className="flex justify-between items-center p-4 bg-blue-600 text-white rounded-t-2xl">
        <h3 className="text-lg font-semibold">Asistente ConPazApp</h3>
        <button onClick={onClose} className="text-white hover:text-gray-200 transition-colors">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        </button>
      </div>
      <div className="flex-grow p-4 overflow-y-auto h-64 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`p-3 rounded-xl max-w-[80%] ${msg.sender === 'user' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>
              <div className="font-semibold text-sm mb-1">
                {msg.sender === 'user' ? 'Tú' : 'Asistente'}
                <span className="ml-2 text-xs opacity-75">{msg.timestamp}</span>
              </div>
              <p>{msg.text}</p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 border-t border-gray-200 flex">
        <input
          type="text"
          className="flex-grow px-4 py-2 border border-gray-300 rounded-l-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
          placeholder="Escribe tu mensaje..."
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyPress={(e) => {
            if (e.key === 'Enter') {
              handleSendMessage();
            }
          }}
        />
        <button
          onClick={handleSendMessage}
          className="px-6 py-2 bg-blue-600 text-white rounded-r-xl font-semibold hover:bg-blue-700 transition-colors"
        >
          Enviar
        </button>
      </div>
    </div>
  );
};

export default ChatbotAssistant;
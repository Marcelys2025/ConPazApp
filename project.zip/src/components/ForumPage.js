import React, { useState } from 'react';

const ForumPage = ({ onBack, currentUser }) => {
  const [posts, setPosts] = useState([
    {
      id: 'p1',
      question: '¿Qué estrategias utilizas para fomentar el respeto en el aula?',
      author: 'Profesor García',
      authorType: 'teacher',
      responses: [
        { id: 'r1', author: 'Ana (Estudiante)', authorType: 'student', text: 'Yo creo que los juegos de rol ayudan mucho a entender otras perspectivas.' },
        { id: 'r2', author: 'Profesora Laura', authorType: 'teacher', text: 'Implemento círculos de diálogo al inicio de cada semana para que todos se expresen.' },
      ],
    },
    {
      id: 'p2',
      question: '¿Cómo manejas los desacuerdos con tus compañeros de forma pacífica?',
      author: 'Carlos (Estudiante)',
      authorType: 'student',
      responses: [
        { id: 'r3', author: 'Sofía (Estudiante)', authorType: 'student', text: 'Intento escuchar primero y luego propongo soluciones que nos beneficien a ambos.' },
      ],
    },
    {
      id: 'p3',
      question: '¿Qué papel crees que tienen los padres en la convivencia escolar?',
      author: 'Directora Elena',
      authorType: 'teacher',
      responses: [],
    },
    // Nuevas preguntas para el foro
    {
      id: 'p4',
      question: '¿Cuál es el mayor desafío que enfrentas al intentar mejorar la convivencia en tu escuela?',
      author: 'Profesor Juan',
      authorType: 'teacher',
      responses: [],
    },
    {
      id: 'p5',
      question: '¿Qué actividad o iniciativa te gustaría que se implementara en tu escuela para fortalecer la convivencia?',
      author: 'María (Estudiante)',
      authorType: 'student',
      responses: [],
    },
    {
      id: 'p6',
      question: '¿Cómo crees que la tecnología (como esta app) puede ayudar a mejorar la convivencia escolar?',
      author: 'Administrador del Sistema',
      authorType: 'teacher', // Asumimos que el administrador es un tipo de docente para este contexto
      responses: [],
    },
  ]);

  const [newResponseText, setNewResponseText] = useState({});

  const handleAddResponse = (postId) => {
    if (newResponseText[postId] && newResponseText[postId].trim()) {
      setPosts(posts.map(post =>
        post.id === postId
          ? {
              ...post,
              responses: [
                ...post.responses,
                {
                  id: Date.now().toString(),
                  author: currentUser.name,
                  authorType: currentUser.userType,
                  text: newResponseText[postId].trim(),
                },
              ],
            }
          : post
      ));
      setNewResponseText({ ...newResponseText, [postId]: '' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Foro de Convivencia
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver
          </button>
        </div>

        <div className="space-y-8">
          {posts.map(post => (
            <div key={post.id} className="bg-blue-50 p-6 rounded-2xl shadow-md border border-blue-200">
              <h3 className="text-xl font-semibold text-blue-800 mb-3">{post.question}</h3>
              <p className="text-gray-700 text-sm mb-4">
                Pregunta de: <span className="font-medium">{post.author}</span> ({post.authorType === 'student' ? 'Estudiante' : 'Docente'})
              </p>

              <div className="space-y-4 pl-4 border-l-2 border-blue-100">
                {post.responses.length === 0 ? (
                  <p className="text-gray-500 text-sm italic">Sé el primero en responder a esta pregunta.</p>
                ) : (
                  post.responses.map(response => (
                    <div key={response.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                      <p className="text-gray-800 mb-2">{response.text}</p>
                      <p className="text-gray-600 text-xs font-medium">
                        - {response.author} ({response.authorType === 'student' ? 'Estudiante' : 'Docente'})
                      </p>
                    </div>
                  ))
                )}
              </div>

              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <textarea
                  className="flex-grow px-4 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 resize-none"
                  rows="2"
                  placeholder="Escribe tu respuesta aquí..."
                  value={newResponseText[post.id] || ''}
                  onChange={(e) => setNewResponseText({ ...newResponseText, [post.id]: e.target.value })}
                ></textarea>
                <button
                  onClick={() => handleAddResponse(post.id)}
                  className="px-6 py-2 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors"
                >
                  Responder
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ForumPage;
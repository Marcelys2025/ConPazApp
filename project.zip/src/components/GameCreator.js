import React, { useState } from 'react';

const GameCreator = ({ onBack, onCreateGame }) => {
  const [gameType, setGameType] = useState('crossword'); // 'crossword' or 'wordsearch'
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [words, setWords] = useState(''); // Para sopas de letras
  const [clue, setClue] = useState(''); // Para crucigramas
  const [answer, setAnswer] = useState(''); // Para crucigramas

  const handleSubmit = () => {
    if (!title || !description) {
      alert('Por favor, completa el título y la descripción del juego.');
      return;
    }

    let newGameData = {
      id: Date.now().toString(),
      title,
      description,
      type: gameType,
      createdBy: 'student', // Asumimos que es creado por un estudiante
    };

    if (gameType === 'crossword') {
      if (!clue || !answer) {
        alert('Para el crucigrama, por favor, añade una pista y la respuesta.');
        return;
      }
      newGameData = { ...newGameData, clue, answer };
    } else if (gameType === 'wordsearch') {
      if (!words) {
        alert('Para la sopa de letras, por favor, añade las palabras separadas por comas.');
        return;
      }
      newGameData = { ...newGameData, words: words.split(',').map(w => w.trim().toUpperCase()) };
    }

    onCreateGame(newGameData);
    onBack(); // Volver a la página de juegos
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-yellow-50 to-orange-100 p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl w-full max-w-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">
            Crea tu Propio Juego
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver
          </button>
        </div>

        <div className="mb-6">
          <label htmlFor="gameType" className="block text-gray-700 text-lg font-semibold mb-2">
            Tipo de Juego
          </label>
          <select
            id="gameType"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 bg-white"
            value={gameType}
            onChange={(e) => setGameType(e.target.value)}
          >
            <option value="crossword">Crucigrama</option>
            <option value="wordsearch">Sopa de Letras</option>
          </select>
        </div>

        <div className="mb-6">
          <label htmlFor="title" className="block text-gray-700 text-lg font-semibold mb-2">
            Título del Juego
          </label>
          <input
            type="text"
            id="title"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
            placeholder="Ej: Crucigrama de Valores"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        <div className="mb-6">
          <label htmlFor="description" className="block text-gray-700 text-lg font-semibold mb-2">
            Descripción del Juego
          </label>
          <textarea
            id="description"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 resize-none"
            rows="3"
            placeholder="Describe brevemente tu juego."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          ></textarea>
        </div>

        {gameType === 'crossword' && (
          <>
            <div className="mb-6">
              <label htmlFor="clue" className="block text-gray-700 text-lg font-semibold mb-2">
                Pista del Crucigrama
              </label>
              <input
                type="text"
                id="clue"
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
                placeholder="Ej: Valor que significa respetar a los demás"
                value={clue}
                onChange={(e) => setClue(e.target.value)}
              />
            </div>
            <div className="mb-6">
              <label htmlFor="answer" className="block text-gray-700 text-lg font-semibold mb-2">
                Respuesta del Crucigrama
              </label>
              <input
                type="text"
                id="answer"
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
                placeholder="Ej: RESPETO"
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
              />
            </div>
          </>
        )}

        {gameType === 'wordsearch' && (
          <div className="mb-6">
            <label htmlFor="words" className="block text-gray-700 text-lg font-semibold mb-2">
              Palabras para la Sopa de Letras (separadas por comas)
            </label>
            <textarea
              id="words"
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 resize-none"
              rows="3"
              placeholder="Ej: PAZ, AMISTAD, DIALOGO, EMPATIA"
              value={words}
              onChange={(e) => setWords(e.target.value)}
            ></textarea>
          </div>
        )}

        <button
          onClick={handleSubmit}
          className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-blue-700 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105"
        >
          Crear Juego
        </button>
      </div>
    </div>
  );
};

export default GameCreator;
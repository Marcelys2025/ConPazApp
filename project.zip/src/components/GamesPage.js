import React, { useState } from 'react';
import GameCreator from './GameCreator'; // Importar el creador de juegos

const GamesPage = ({ onBack, userCreatedGames, onCreateGame }) => {
  const [selectedGame, setSelectedGame] = useState(null);
  const [showCreator, setShowCreator] = useState(false);

  const predefinedGames = [
    {
      id: 'crossword-predefined',
      title: 'Crucigrama de la Convivencia',
      description: 'Pon a prueba tus conocimientos sobre valores y respeto completando este crucigrama.',
      type: 'crossword',
      clue: 'Valor fundamental para una buena convivencia, significa considerar y valorar a los demás.',
      answer: 'RESPETO',
    },
    {
      id: 'wordsearch-predefined',
      title: 'Sopa de Letras de la Paz',
      description: 'Encuentra palabras clave relacionadas con la convivencia y la resolución de conflictos.',
      type: 'wordsearch',
      words: ['PAZ', 'RESPETO', 'DIALOGO', 'EMPATIA', 'AMISTAD'],
    },
  ];

  const allGames = [...predefinedGames, ...userCreatedGames];

  const renderGameComponent = () => {
    if (showCreator) {
      return <GameCreator onBack={() => setShowCreator(false)} onCreateGame={onCreateGame} />;
    }

    if (!selectedGame) {
      return (
        <>
          <div className="mb-8 p-6 bg-yellow-50 rounded-2xl border border-yellow-200 shadow-md">
            <h3 className="text-xl font-semibold text-yellow-800 mb-3">Crea tu Propio Juego</h3>
            <p className="text-gray-700 mb-4">Diseña tus propios crucigramas o sopas de letras y compártelos.</p>
            <button
              onClick={() => setShowCreator(true)}
              className="px-6 py-3 bg-yellow-600 text-white rounded-xl font-semibold hover:bg-yellow-700 transition-colors"
            >
              Crear Juego
            </button>
          </div>

          <h3 className="text-2xl font-bold text-gray-900 mb-6">Juegos Disponibles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {allGames.map(game => (
              <div key={game.id} className="bg-blue-50 p-6 rounded-2xl shadow-md border border-blue-200 transform transition-all duration-300 hover:scale-105 hover:shadow-xl">
                <h4 className="text-xl font-semibold text-blue-800 mb-3">{game.title}</h4>
                <p className="text-gray-700 mb-4">{game.description}</p>
                <p className="text-gray-600 text-sm mb-2">Tipo: {game.type === 'crossword' ? 'Crucigrama' : 'Sopa de Letras'}</p>
                {game.createdBy && <p className="text-gray-600 text-sm">Creado por: {game.createdBy}</p>}
                <button
                  onClick={() => setSelectedGame(game)}
                  className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
                >
                  Jugar
                </button>
              </div>
            ))}
          </div>
        </>
      );
    } else {
      // Renderizar el juego seleccionado
      if (selectedGame.type === 'crossword') {
        return <CrosswordGame gameData={selectedGame} onBackToGames={() => setSelectedGame(null)} />;
      } else if (selectedGame.type === 'wordsearch') {
        return <WordSearchGame gameData={selectedGame} onBackToGames={() => setSelectedGame(null)} />;
      }
      return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-100 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Juegos de Convivencia
          </h2>
          <button
            onClick={showCreator || selectedGame ? () => { setShowCreator(false); setSelectedGame(null); } : onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            {showCreator || selectedGame ? 'Volver a Juegos' : 'Volver'}
          </button>
        </div>

        {renderGameComponent()}
      </div>
    </div>
  );
};

// Componente de Crucigrama
const CrosswordGame = ({ gameData, onBackToGames }) => {
  const [answer, setAnswer] = useState('');
  const [message, setMessage] = useState('');

  const checkAnswer = () => {
    if (answer.toLowerCase() === gameData.answer.toLowerCase()) {
      setMessage('¡Correcto! 🎉');
    } else {
      setMessage('Incorrecto. Intenta de nuevo. 🤔');
    }
  };

  return (
    <div className="p-6 bg-white rounded-2xl shadow-md border border-gray-200">
      <h4 className="text-2xl font-semibold text-gray-900 mb-4">{gameData.title}</h4>
      <p className="text-gray-700 mb-4">
        Pista: {gameData.clue}
      </p>
      <input
        type="text"
        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 mb-4"
        placeholder="Escribe tu respuesta aquí..."
        value={answer}
        onChange={(e) => setAnswer(e.target.value)}
      />
      <button
        onClick={checkAnswer}
        className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-blue-700 transition-colors"
      >
        Comprobar
      </button>
      {message && <p className="mt-4 text-center text-lg font-medium">{message}</p>}
    </div>
  );
};

// Componente de Sopa de Letras
const WordSearchGame = ({ gameData, onBackToGames }) => {
  const [foundWords, setFoundWords] = useState([]);
  const [message, setMessage] = useState('');
  const [inputWord, setInputWord] = useState('');

  const handleWordFound = () => {
    const word = inputWord.trim().toUpperCase();
    if (gameData.words.includes(word) && !foundWords.includes(word)) {
      setFoundWords([...foundWords, word]);
      setMessage(`¡Encontraste una palabra: ${word}!`);
      if (foundWords.length + 1 === gameData.words.length) {
        setMessage('¡Felicidades! Encontraste todas las palabras. 🎉');
      }
    } else if (word) {
      setMessage('Esa palabra no está en la lista o ya la encontraste. 🤔');
    }
    setInputWord('');
  };

  return (
    <div className="p-6 bg-white rounded-2xl shadow-md border border-gray-200">
      <h4 className="text-2xl font-semibold text-gray-900 mb-4">{gameData.title}</h4>
      <p className="text-gray-700 mb-4">
        Palabras a encontrar: {gameData.words.join(', ')}
      </p>
      <div className="grid grid-cols-5 gap-1 mb-4">
        {/* Simulación de la cuadrícula de la sopa de letras */}
        {['P', 'A', 'Z', 'X', 'Y', 'R', 'E', 'S', 'P', 'E', 'T', 'O', 'D', 'I', 'A', 'L', 'O', 'G', 'O', 'E', 'M', 'P', 'A', 'T', 'I', 'A', 'M', 'I', 'S', 'T', 'A', 'D', 'Q', 'W', 'E'].map((letter, index) => (
          <span key={index} className="flex items-center justify-center w-8 h-8 bg-gray-100 border border-gray-200 text-gray-800 font-bold">
            {letter}
          </span>
        ))}
      </div>
      <input
        type="text"
        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 mb-4"
        placeholder="Escribe una palabra que encuentres..."
        value={inputWord}
        onChange={(e) => setInputWord(e.target.value)}
        onKeyPress={(e) => {
          if (e.key === 'Enter') {
            handleWordFound();
          }
        }}
      />
      <button
        onClick={handleWordFound}
        className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-blue-700 transition-colors"
      >
        Comprobar Palabra
      </button>
      {message && <p className="mt-4 text-center text-lg font-medium">{message}</p>}
      <p className="mt-2 text-center text-gray-600">Palabras encontradas: {foundWords.join(', ')}</p>
    </div>
  );
};

export default GamesPage;
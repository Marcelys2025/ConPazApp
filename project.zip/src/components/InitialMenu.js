import React from 'react';
import AppLogo from './AppLogo';

const InitialMenu = ({ onSelectRole, onNavigate }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-200 via-purple-200 to-pink-200 p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl w-full max-w-md border border-gray-200 text-center">
        <div className="mb-8 flex justify-center">
          <AppLogo />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-8">
          Bienvenido a ConPazApp
        </h2>

        <p className="text-lg text-gray-700 mb-6">
          Selecciona tu rol para continuar:
        </p>

        <div className="space-y-4 mb-8">
          <button
            onClick={() => onSelectRole('student')}
            className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-blue-700 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105"
          >
            Soy Estudiante
          </button>
          <button
            onClick={() => onSelectRole('teacher')}
            className="w-full bg-purple-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-purple-700 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105"
          >
            Soy Docente
          </button>
        </div>

        <p className="text-lg text-gray-700 mb-6">
          O explora nuestras secciones:
        </p>

        <div className="space-y-3">
          <button
            onClick={() => onNavigate('reportsList')}
            className="w-full bg-gray-200 text-gray-800 py-3 rounded-xl font-semibold text-lg hover:bg-gray-300 transition-colors"
          >
            Reportes
          </button>
          <button
            onClick={() => onNavigate('videos')}
            className="w-full bg-gray-200 text-gray-800 py-3 rounded-xl font-semibold text-lg hover:bg-gray-300 transition-colors"
          >
            Recursos (Videos)
          </button>
          {/* Botón de Foro, que aún no está implementado */}
          <button
            onClick={() => alert('El foro estará disponible pronto. ¡Mantente atento!')}
            className="w-full bg-gray-200 text-gray-800 py-3 rounded-xl font-semibold text-lg hover:bg-gray-300 transition-colors opacity-70 cursor-not-allowed"
            disabled
          >
            Foro (Próximamente)
          </button>
        </div>
      </div>
    </div>
  );
};

export default InitialMenu;
import React, { useState } from 'react';
import AvatarDisplay from './AvatarDisplay';

const InteractiveEnvironment = ({ currentUser, onBack }) => {
  // Simulación de otros usuarios en el entorno
  const [usersInEnvironment] = useState([
    { id: 1, name: 'Ana', userType: 'student', avatarUrl: 'https://randomuser.me/api/portraits/women/1.jpg' },
    { id: 2, name: 'Carlos', userType: 'teacher', avatarUrl: 'https://randomuser.me/api/portraits/men/2.jpg' },
    { id: 3, name: 'Sofía', userType: 'student', avatarUrl: 'https://randomuser.me/api/portraits/women/3.jpg' },
    { id: 4, name: 'Dr. García', userType: 'teacher', avatarUrl: 'https://randomuser.me/api/portraits/men/4.jpg' },
  ]);

  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');

  // Mapa de emojis para reemplazar códigos cortos
  const emojiMap = {
    ':)': '😊', ':(': '😞', ':D': '😁', ';)': '😉', ':P': '😛', '<3': '❤️',
    ':fire:': '🔥', ':clap:': '👏', ':thumbsup:': '👍', ':thumbsdown:': '👎',
    ':joy:': '😂', ':thinking:': '🤔', ':party:': '🥳', ':star:': '⭐',
    ':rocket:': '🚀', ':bulb:': '💡', ':peace:': '✌️', ':wave:': '👋',
    ':ok_hand:': '👌', ':pray:': '🙏', ':muscle:': '💪', ':sparkles:': '✨',
    ':tada:': '🎉', ':robot:': '🤖', ':ghost:': '👻', ':alien:': '👽',
    ':pizza:': '🍕', ':coffee:': '☕', ':book:': '📚', ':pencil:': '✏️',
    ':school:': '🏫', ':apple:': '🍎', ':bell:': '🔔', ':warning:': '⚠️',
    ':check:': '✅', ':x:': '❌', ':question:': '❓', ':exclamation:': '❗',
    ':heart_eyes:': '😍', ':blush:': '😊', ':sweat_smile:': '😅', ':sob:': '😭',
    ':rage:': '😡', ':mask:': '😷', ':sunglasses:': '😎', ':nerd:': '🤓',
    ':cool:': '🆒', ':100:': '💯', ':boom:': '💥', ':zap:': '⚡',
    ':collision:': '💥', ':sparkle:': '✨', ':balloon:': '🎈', ':gift:': '🎁',
    ':trophy:': '🏆', ':medal:': '🏅', ':first_place:': '🥇', ':second_place:': '🥈',
    ':third_place:': '🥉', ':raised_hands:': '🙌', ':point_up:': '☝️',
    ':point_down:': '👇', ':point_left:': '👈', ':point_right:': '👉',
    ':fist:': '✊', ':v:': '✌️', ':call_me:': '🤙', ':metal:': '🤘',
    ':vulcan:': '🖖', ':walking:': '🚶', ':running:': '🏃', ':swimmer:': '🏊',
    ':biker:': '🚴', ':golfer:': '🏌️', ':surfer:': '🏄', ':tennis:': '🎾',
    ':basketball:': '🏀', ':football:': '🏈', ':baseball:': '⚾', ':soccer:': '⚽',
    ':volleyball:': '🏐', ':rugby_football:': '🏉', ':cricket_game:': '🏏',
    ':field_hockey:': '🏑', ':ice_hockey:': '🏒', ':table_tennis:': '🏓',
    ':badminton:': '🏸', ':boxing_glove:': '🥊', ':martial_arts_uniform:': '🥋',
    ':goal_net:': '🥅', ':ice_skate:': '⛸️', ':fishing_pole_and_fish:': '🎣',
    ':diving_mask:': '🤿', ':bow_and_arrow:': '🏹', ':skateboard:': '🛹',
    ':sled:': '🛷', ':curling_stone:': '🥌', ':lacrosse_stick_and_ball:': '🥍',
    ':softball:': '🥎', ':flying_disc:': '🥏', ':frisbee:': '🥏', ':yo_yo:': '🪀',
    ':kite:': '🪁', ':ringed_planet:': '🪐', ':star_struck:': '🤩',
    ':zany_face:': '🤪', ':shushing_face:': '🤫', ':face_with_symbols_on_mouth:': '🤬',
    ':exploding_head:': '🤯', ':face_with_monocle:': '🧐', ':cowboy_hat_face:': '🤠',
    ':partying_face:': '🥳', ':woozy_face:': '🥴', ':hot_face:': '🥵',
    ':cold_face:': '🥶', ':pleading_face:': '🥺', ':face_with_hand_over_mouth:': '🤭',
    ':yawning_face:': '🥱', ':smiling_face_with_tear:': '🥲', ':disguised_face:': '🥸',
    ':face_holding_back_tears:': '🥹', ':face_with_peeking_eye:': '🫣',
    ':saluting_face:': '🫡', ':melting_face:': '🫠',
    ':face_with_open_eyes_and_hand_over_mouth:': '🫢', ':face_with_diagonal_mouth:': '🫤',
    ':dotted_line_face:': '🫥', ':face_with_spiral_eyes:': '😵‍💫',
    ':face_in_clouds:': '😶‍🌫️', ':face_exhaling:': '😮‍💨',
    ':face_with_head_bandage:': '🤕', ':nauseated_face:': '🤢',
    ':vomiting_face:': '🤮', ':sneezing_face:': '🤧',
  };

  const applyEmojis = (text) => {
    let result = text;
    for (const key in emojiMap) {
      result = result.split(key).join(emojiMap[key]);
    }
    return result;
  };

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      setMessages([...messages, {
        id: messages.length + 1,
        sender: currentUser.name,
        userType: currentUser.userType,
        text: applyEmojis(newMessage.trim()), // Aplicar emojis al mensaje
        timestamp: new Date().toLocaleTimeString(),
      }]);
      setNewMessage('');
    }
  };

  // Función para añadir emojis al mensaje
  const addEmoji = (emoji) => {
    setNewMessage(prevMsg => prevMsg + emoji);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-300 p-4 sm:p-8">
      <div className="max-w-7xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Entorno Interactivo: Plaza de la Convivencia
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Sección del Entorno Visual */}
          <div className="lg:col-span-2 relative w-full h-96 bg-gradient-to-br from-green-200 to-blue-200 rounded-2xl shadow-inner flex items-center justify-center overflow-hidden">
            {/* Fondo interactivo simulado */}
            <div className="absolute inset-0 bg-cover bg-center opacity-30" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1506748687220-b1d1170d7e57?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')" }}></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-gray-800 text-2xl font-bold text-shadow-lg">
                ¡Explora y Conecta!
              </p>
            </div>

            {/* Avatares en el entorno */}
            <div className="absolute top-1/4 left-1/4">
              <AvatarDisplay
                avatarUrl={currentUser.avatarUrl || 'https://via.placeholder.com/60/F3F4F6/9CA3AF?text=YO'}
                name={currentUser.name}
                userType={currentUser.userType}
              />
            </div>
            {usersInEnvironment.map((user) => (
              <div key={user.id} className={`absolute`} style={{
                top: `${Math.random() * 70 + 10}%`, // Posición aleatoria
                left: `${Math.random() * 70 + 10}%`,
              }}>
                <AvatarDisplay {...user} />
              </div>
            ))}
          </div>

          {/* Sección del Chat */}
          <div className="lg:col-span-1 bg-gray-50 p-6 rounded-2xl shadow-md border border-gray-200 flex flex-col h-96">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Chat del Entorno</h3>
            <div className="flex-grow overflow-y-auto mb-4 space-y-3 pr-2">
              {messages.length === 0 && (
                <p className="text-gray-500 text-center mt-4">¡Sé el primero en saludar! 👋</p>
              )}
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.sender === currentUser.name ? 'justify-end' : 'justify-start'}`}>
                  <div className={`p-3 rounded-xl max-w-[80%] ${msg.sender === currentUser.name ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800'}`}>
                    <div className="font-semibold text-sm mb-1">
                      {msg.sender === currentUser.name ? 'Tú' : msg.sender}
                      <span className="ml-2 text-xs opacity-75">{msg.timestamp}</span>
                    </div>
                    <p>{msg.text}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex flex-col">
              <div className="flex justify-around mb-2">
                <button onClick={() => addEmoji('😀')} className="text-2xl hover:scale-110 transition-transform">😀</button>
                <button onClick={() => addEmoji('👍')} className="text-2xl hover:scale-110 transition-transform">👍</button>
                <button onClick={() => addEmoji('❤️')} className="text-2xl hover:scale-110 transition-transform">❤️</button>
                <button onClick={() => addEmoji('😂')} className="text-2xl hover:scale-110 transition-transform">😂</button>
                <button onClick={() => addEmoji('📚')} className="text-2xl hover:scale-110 transition-transform">📚</button>
                <button onClick={() => addEmoji('🤝')} className="text-2xl hover:scale-110 transition-transform">🤝</button>
              </div>
              <div className="flex">
                <input
                  type="text"
                  className="flex-grow px-4 py-2 border border-gray-300 rounded-l-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
                  placeholder="Escribe tu mensaje..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      handleSendMessage();
                    }
                  }}
                />
                <button
                  onClick={handleSendMessage}
                  className="px-6 py-2 bg-blue-600 text-white rounded-r-xl font-semibold hover:bg-blue-700 transition-colors"
                >
                  Enviar
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 p-6 rounded-2xl shadow-md border border-blue-200 mt-8">
          <h3 className="text-xl font-semibold text-blue-800 mb-3">Tu Avatar Actual</h3>
          <div className="flex items-center space-x-4">
            <AvatarDisplay
              avatarUrl={currentUser.avatarUrl || 'https://via.placeholder.com/60/F3F4F6/9CA3AF?text=YO'}
              name={currentUser.name}
              userType={currentUser.userType}
            />
            <p className="text-gray-700">
              Este es tu avatar en el entorno interactivo. ¡Puedes personalizarlo pronto!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InteractiveEnvironment;
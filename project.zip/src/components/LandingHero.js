import React from 'react';

const LandingHero = () => {
  return (
    <section className="relative h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 text-center p-4 sm:p-8">
      <div className="max-w-4xl mx-auto bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl p-8 sm:p-12 border border-gray-200">
        <h1 className="text-4xl sm:text-6xl font-extrabold text-gray-900 leading-tight mb-6">
          Tu Visión, Hecha Realidad.
        </h1>
        <p className="text-lg sm:text-xl text-gray-700 mb-10 max-w-2xl mx-auto">
          Diseñamos experiencias digitales que no solo se ven increíbles, sino que también funcionan a la perfección.
        </p>
        <button className="px-8 py-4 bg-black text-white text-lg font-semibold rounded-xl shadow-lg hover:bg-gray-800 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105">
          Descubre Más
        </button>
      </div>
    </section>
  );
};

export default LandingHero;
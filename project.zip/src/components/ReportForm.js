import React, { useState } from 'react';

const ReportForm = ({ onSubmitReport, onBack }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [anonymous, setAnonymous] = useState(false);

  const handleSubmit = () => {
    if (title && description) {
      onSubmitReport({ title, description, anonymous });
    } else {
      alert('Por favor, completa el título y la descripción del reporte.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-100 p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl w-full max-w-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">
            Reportar un Conflicto
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver
          </button>
        </div>

        <div className="mb-6">
          <label htmlFor="title" className="block text-gray-700 text-lg font-semibold mb-2">
            Título del Reporte
          </label>
          <input
            type="text"
            id="title"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 transition duration-200"
            placeholder="Ej: Discusión en el recreo"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        <div className="mb-6">
          <label htmlFor="description" className="block text-gray-700 text-lg font-semibold mb-2">
            Descripción del Conflicto
          </label>
          <textarea
            id="description"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 transition duration-200 resize-none"
            rows="5"
            placeholder="Describe lo sucedido, quiénes estuvieron involucrados y cuándo ocurrió."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          ></textarea>
        </div>

        <div className="mb-8 flex items-center">
          <input
            type="checkbox"
            id="anonymous"
            className="form-checkbox h-5 w-5 text-red-600"
            checked={anonymous}
            onChange={(e) => setAnonymous(e.target.checked)}
          />
          <label htmlFor="anonymous" className="ml-2 text-gray-700 text-lg">
            Enviar de forma anónima
          </label>
        </div>

        <button
          onClick={handleSubmit}
          className="w-full bg-red-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-red-700 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105"
        >
          Enviar Reporte
        </button>
      </div>
    </div>
  );
};

export default ReportForm;
import React from 'react';

const ReportsListPage = ({ reports, onBack, onUpdateReportStatus }) => {
  const statusColors = {
    'Pendiente': 'bg-yellow-100 text-yellow-800',
    'En Proceso': 'bg-blue-100 text-blue-800',
    'Resuelto': 'bg-green-100 text-green-800',
    'Cerrado': 'bg-gray-100 text-gray-800',
  };

  const handleStatusChange = (reportId, newStatus) => {
    onUpdateReportStatus(reportId, newStatus);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-100 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Reportes de Conflictos
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver
          </button>
        </div>

        {reports.length === 0 ? (
          <p className="text-center text-gray-600 text-lg mt-10">
            No hay reportes de conflictos en este momento.
          </p>
        ) : (
          <div className="space-y-6">
            {reports.map((report) => (
              <div key={report.id} className="bg-gray-50 p-6 rounded-2xl shadow-md border border-gray-200">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{report.title}</h3>
                <p className="text-gray-700 mb-3">{report.description}</p>
                <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
                  <span>Reportado por: {report.anonymous ? 'Anónimo' : report.reporter}</span>
                  <span>Fecha: {report.date}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${statusColors[report.status]}`}>
                    Estado: {report.status}
                  </span>
                  <select
                    value={report.status}
                    onChange={(e) => handleStatusChange(report.id, e.target.value)}
                    className="ml-4 px-3 py-1 border border-gray-300 rounded-xl bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Pendiente">Pendiente</option>
                    <option value="En Proceso">En Proceso</option>
                    <option value="Resuelto">Resuelto</option>
                    <option value="Cerrado">Cerrado</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportsListPage;
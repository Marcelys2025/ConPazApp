import React, { useState } from 'react';
import VideoResourcesPage from './VideoResourcesPage'; // Asumiendo que ya tienes este componente
// import CapsulesPage from './CapsulesPage'; // Necesitarías crear este componente

const ResourcesPage = ({ userType, onBack }) => {
  const [selectedResourceMenu, setSelectedResourceMenu] = useState(null); // 'videos' or 'capsules'

  const renderContent = () => {
    if (selectedResourceMenu === 'videos') {
      return <VideoResourcesPage userType={userType} onBack={() => setSelectedResourceMenu(null)} />;
    }
    // else if (selectedResourceMenu === 'capsules') {
    //   return <CapsulesPage userType={userType} onBack={() => setSelectedResourceMenu(null)} />;
    // }
    else {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-blue-50 p-6 rounded-2xl shadow-md border border-blue-200 transform transition-all duration-300 hover:scale-105 hover:shadow-xl">
            <h3 className="text-xl font-semibold text-blue-800 mb-3">Videos de Convivencia</h3>
            <p className="text-gray-700 mb-4">Explora nuestra biblioteca de videos sobre convivencia, resolución de conflictos y bienestar emocional.</p>
            <button
              onClick={() => setSelectedResourceMenu('videos')}
              className="px-6 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
            >
              Ver Videos
            </button>
          </div>
          <div className="bg-green-50 p-6 rounded-2xl shadow-md border border-green-200 transform transition-all duration-300 hover:scale-105 hover:shadow-xl">
            <h3 className="text-xl font-semibold text-green-800 mb-3">Cápsulas Formativas</h3>
            <p className="text-gray-700 mb-4">Accede a pequeñas lecciones interactivas y resúmenes sobre temas clave de convivencia.</p>
            <button
              onClick={() => alert('Las Cápsulas Formativas estarán disponibles pronto.')} // Placeholder
              // onClick={() => setSelectedResourceMenu('capsules')} // Descomentar cuando CapsulesPage esté lista
              className="px-6 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors"
            >
              Ver Cápsulas
            </button>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-100 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Recursos
          </h2>
          <button
            onClick={selectedResourceMenu ? () => setSelectedResourceMenu(null) : onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            {selectedResourceMenu ? 'Volver a Recursos' : 'Volver'}
          </button>
        </div>

        {renderContent()}
      </div>
    </div>
  );
};

export default ResourcesPage;
import React from 'react';
import AppLogo from './AppLogo'; // Importar el logo
import AppNavigation from './AppNavigation'; // Importar el menú de navegación

const StudentDashboard = ({ username, onLogout, onNavigate, currentView }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-100 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="mb-6 flex justify-between items-center">
          <AppLogo />
          <button
            onClick={onLogout}
            className="px-4 py-2 bg-red-600 text-white rounded-xl font-semibold text-sm shadow-lg hover:bg-red-700 transition-all duration-300"
          >
            Cerrar Sesión
          </button>
        </div>
        <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
          ¡Hola, {username}!
        </h2>
        <p className="text-lg text-gray-700 mb-8">
          Bienvenido a tu panel de estudiante en ConPazApp. Aquí encontrarás recursos y actividades para mejorar la convivencia escolar.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-blue-50 p-6 rounded-2xl shadow-md border border-blue-200">
            <h3 className="text-xl font-semibold text-blue-800 mb-3">Mis Actividades</h3>
            <p className="text-gray-700">Consulta las actividades y talleres disponibles para ti.</p>
            <button
              onClick={() => onNavigate('activities')}
              className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
            >
              Ver Actividades
            </button>
          </div>
          <div className="bg-purple-50 p-6 rounded-2xl shadow-md border border-purple-200">
            <h3 className="text-xl font-semibold text-purple-800 mb-3">Reportar Situación</h3>
            <p className="text-gray-700">Si necesitas ayuda o reportar un incidente, hazlo aquí.</p>
            <button
              onClick={() => onNavigate('reportForm')} // Botón para ir al formulario de reporte
              className="mt-4 px-6 py-2 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors"
            >
              Reportar
            </button>
          </div>
          <div className="bg-teal-50 p-6 rounded-2xl shadow-md border border-teal-200">
            <h3 className="text-xl font-semibold text-teal-800 mb-3">Recursos de Video</h3>
            <p className="text-gray-700">Explora videos sobre convivencia y bienestar.</p>
            <button
              onClick={() => onNavigate('videos')}
              className="mt-4 px-6 py-2 bg-teal-600 text-white rounded-xl hover:bg-teal-700 transition-colors"
            >
              Ver Videos
            </button>
          </div>
          <div className="bg-orange-50 p-6 rounded-2xl shadow-md border border-orange-200">
            <h3 className="text-xl font-semibold text-orange-800 mb-3">Entorno Interactivo</h3>
            <p className="text-gray-700">Conéctate con otros usuarios en un espacio virtual.</p>
            <button
              onClick={() => onNavigate('interactive')}
              className="mt-4 px-6 py-2 bg-orange-600 text-white rounded-xl hover:bg-orange-700 transition-colors"
            >
              Entrar
            </button>
          </div>
          <div className="bg-pink-50 p-6 rounded-2xl shadow-md border border-pink-200">
            <h3 className="text-xl font-semibold text-pink-800 mb-3">Módulo de Capacitación</h3>
            <p className="text-gray-700">Aprende sobre convivencia y justicia restaurativa de forma interactiva.</p>
            <button
              onClick={() => onNavigate('training')}
              className="mt-4 px-6 py-2 bg-pink-600 text-white rounded-xl hover:bg-pink-700 transition-colors"
            >
              Iniciar Módulo
            </button>
          </div>
          {/* Nuevo botón para Juegos */}
          <div className="bg-yellow-50 p-6 rounded-2xl shadow-md border border-yellow-200">
            <h3 className="text-xl font-semibold text-yellow-800 mb-3">Juegos de Convivencia</h3>
            <p className="text-gray-700">Diviértete y aprende con crucigramas y sopas de letras.</p>
            <button
              onClick={() => onNavigate('games')}
              className="mt-4 px-6 py-2 bg-yellow-600 text-white rounded-xl hover:bg-yellow-700 transition-colors"
            >
              Jugar
            </button>
          </div>
        </div>
        <button
          onClick={() => onNavigate('survey')}
          className="w-full bg-indigo-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-indigo-700 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 mt-4"
        >
          Realizar Encuesta de Entrada
        </button>
      </div>
      <AppNavigation userType={userType} onNavigate={onNavigate} currentView={currentView} />
    </div>
  );
};

export default StudentDashboard;
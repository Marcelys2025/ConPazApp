import React, { useState } from 'react';

const SurveyForm = ({ userType, onSubmitSurvey }) => {
  const [question1, setQuestion1] = useState('');
  const [question2, setQuestion2] = useState('');
  const [question3, setQuestion3] = useState('');

  const handleSubmit = () => {
    if (question1 && question2 && question3) {
      onSubmitSurvey({ question1, question2, question3 });
    } else {
      alert('Por favor, responde todas las preguntas de la encuesta.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-100 via-pink-100 to-red-100 p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl w-full max-w-2xl border border-gray-200 transform transition-all duration-700 ease-out scale-95 opacity-0 animate-fade-in-scale">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-4">
          Encuesta de Entrada
        </h2>
        <p className="text-gray-600 text-center mb-8 text-xl">
          Para {userType === 'student' ? 'Estudiantes' : 'Docentes'}
        </p>

        <div className="space-y-8">
          <div className="bg-blue-50 p-6 rounded-2xl shadow-md border border-blue-200">
            <label htmlFor="q1" className="block text-gray-800 text-lg font-semibold mb-3">
              1. ¿Cómo describirías el ambiente de convivencia en tu escuela actualmente?
            </label>
            <textarea
              id="q1"
              className="w-full px-4 py-3 border border-blue-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200 resize-none text-gray-700"
              rows="3"
              placeholder="Escribe tu respuesta aquí..."
              value={question1}
              onChange={(e) => setQuestion1(e.target.value)}
            ></textarea>
          </div>

          <div className="bg-green-50 p-6 rounded-2xl shadow-md border border-green-200">
            <label htmlFor="q2" className="block text-gray-800 text-lg font-semibold mb-3">
              2. ¿Qué crees que es lo más importante para una buena convivencia escolar?
            </label>
            <textarea
              id="q2"
              className="w-full px-4 py-3 border border-green-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 transition duration-200 resize-none text-gray-700"
              rows="3"
              placeholder="Escribe tu respuesta aquí..."
              value={question2}
              onChange={(e) => setQuestion2(e.target.value)}
            ></textarea>
          </div>

          <div className="bg-yellow-50 p-6 rounded-2xl shadow-md border border-yellow-200">
            <label htmlFor="q3" className="block text-gray-800 text-lg font-semibold mb-3">
              3. ¿Qué te gustaría que ConPazApp te ofreciera para mejorar la convivencia?
            </label>
            <textarea
              id="q3"
              className="w-full px-4 py-3 border border-yellow-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-yellow-500 transition duration-200 resize-none text-gray-700"
              rows="3"
              placeholder="Escribe tu respuesta aquí..."
              value={question3}
              onChange={(e) => setQuestion3(e.target.value)}
            ></textarea>
          </div>
        </div>

        <button
          onClick={handleSubmit}
          className="w-full mt-10 bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-4 rounded-xl font-semibold text-lg shadow-lg hover:from-purple-700 hover:to-indigo-700 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105"
        >
          Enviar Encuesta
        </button>
      </div>
    </div>
  );
};

export default SurveyForm;
import React, { useState, useEffect } from 'react';

const TrainingModule = ({ userType, onBack, onSaveProgress, savedProgress }) => {
  const [currentStep, setCurrentStep] = useState(savedProgress.currentStep || 0);
  const [quizAnswers, setQuizAnswers] = useState(savedProgress.quizAnswers || {});
  const [quizSubmitted, setQuizSubmitted] = useState(savedProgress.quizSubmitted || false);
  const [score, setScore] = useState(savedProgress.score || 0);

  const moduleContent = [
    {
      type: 'intro',
      title: 'Bienvenido al Módulo de Capacitación',
      text: 'Este módulo interactivo te ayudará a comprender mejor los principios de la convivencia escolar y la justicia restaurativa. ¡Prepárate para aprender de una forma divertida!',
      image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    },
    {
      type: 'content',
      title: '¿Qué es la Convivencia Escolar?',
      text: 'La convivencia escolar se refiere al conjunto de relaciones interpersonales que se establecen entre todos los miembros de la comunidad educativa: estudiantes, docentes, directivos, personal administrativo y familias. Un ambiente de convivencia positivo es aquel donde prevalece el respeto, la inclusión, la participación y la resolución pacífica de conflictos.',
      image: 'https://images.unsplash.com/photo-1523050854805-d3b378540902?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    },
    {
      type: 'content',
      title: 'Principios de la Justicia Restaurativa',
      text: 'La justicia restaurativa es un enfoque que busca reparar el daño causado por un conflicto o delito, involucrando a las víctimas, los ofensores y la comunidad. Se centra en el diálogo, la responsabilidad y la reconstrucción de relaciones, en lugar de solo castigar. Sus principios clave son: reparación, encuentro, reintegración y transformación.',
      image: 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    },
    {
      type: 'quiz',
      title: '¡Pon a Prueba tus Conocimientos!',
      questions: [
        {
          id: 'q1',
          question: '¿Cuál es uno de los principios clave de la justicia restaurativa?',
          options: ['Castigo', 'Venganza', 'Reparación', 'Aislamiento'],
          correctAnswer: 'Reparación',
        },
        {
          id: 'q2',
          question: '¿Quiénes participan en la convivencia escolar?',
          options: ['Solo estudiantes', 'Solo docentes', 'Toda la comunidad educativa', 'Solo directivos'],
          correctAnswer: 'Toda la comunidad educativa',
        },
      ],
    },
    {
      type: 'outro',
      title: '¡Felicidades, has completado el módulo!',
      text: 'Esperamos que hayas aprendido mucho y que apliques estos conocimientos para fomentar un ambiente de paz y respeto en tu entorno escolar. ¡Gracias por tu compromiso!',
      image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    },
  ];

  // Guardar progreso cada vez que cambian los estados relevantes
  useEffect(() => {
    onSaveProgress({ currentStep, quizAnswers, quizSubmitted, score });
  }, [currentStep, quizAnswers, quizSubmitted, score, onSaveProgress]);

  const handleNext = () => {
    if (currentStep < moduleContent.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Si es el último paso y es un quiz, calcular el score
      if (moduleContent[currentStep].type === 'quiz' && !quizSubmitted) {
        handleSubmitQuiz();
      } else {
        // Si ya se envió el quiz o es el final, volver atrás
        onBack();
      }
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      setQuizSubmitted(false); // Resetear el estado del quiz si se regresa
      setScore(0);
    }
  };

  const handleQuizAnswer = (questionId, answer) => {
    setQuizAnswers({ ...quizAnswers, [questionId]: answer });
  };

  const handleSubmitQuiz = () => {
    let newScore = 0;
    moduleContent[currentStep].questions.forEach(q => {
      if (quizAnswers[q.id] === q.correctAnswer) {
        newScore++;
      }
    });
    setScore(newScore);
    setQuizSubmitted(true);
  };

  const currentStepData = moduleContent[currentStep];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-blue-100 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Módulo de Capacitación
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Salir
          </button>
        </div>

        <div className="bg-gray-50 p-6 rounded-2xl shadow-md border border-gray-200 mb-8">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">{currentStepData.title}</h3>
          {currentStepData.image && (
            <img src={currentStepData.image} alt="Módulo de Capacitación" className="w-full h-64 object-cover rounded-xl mb-4 shadow-lg" />
          )}

          {currentStepData.type === 'content' && (
            <p className="text-gray-700 text-lg leading-relaxed">{currentStepData.text}</p>
          )}

          {currentStepData.type === 'quiz' && (
            <div>
              {currentStepData.questions.map((q, index) => (
                <div key={q.id} className="mb-6 p-4 bg-white rounded-xl shadow-sm border border-gray-100">
                  <p className="text-gray-800 font-medium text-lg mb-3">{index + 1}. {q.question}</p>
                  <div className="space-y-2">
                    {q.options.map(option => (
                      <label key={option} className="flex items-center text-gray-700 cursor-pointer">
                        <input
                          type="radio"
                          name={q.id}
                          value={option}
                          checked={quizAnswers[q.id] === option}
                          onChange={() => handleQuizAnswer(q.id, option)}
                          disabled={quizSubmitted}
                          className="form-radio h-5 w-5 text-blue-600"
                        />
                        <span className="ml-2">{option}</span>
                        {quizSubmitted && quizAnswers[q.id] === option && (
                          <span className={`ml-2 ${option === q.correctAnswer ? 'text-green-600' : 'text-red-600'}`}>
                            {option === q.correctAnswer ? '✅ Correcto' : '❌ Incorrecto'}
                          </span>
                        )}
                      </label>
                    ))}
                  </div>
                  {quizSubmitted && quizAnswers[q.id] !== q.correctAnswer && (
                    <p className="text-green-600 text-sm mt-2">Respuesta correcta: {q.correctAnswer}</p>
                  )}
                </div>
              ))}
              {!quizSubmitted && (
                <button
                  onClick={handleSubmitQuiz}
                  className="w-full bg-green-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:bg-green-700 transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-105 mt-6"
                >
                  Enviar Respuestas
                </button>
              )}
              {quizSubmitted && (
                <p className="text-center text-2xl font-bold mt-6">
                  Tu puntuación: {score} / {currentStepData.questions.length}
                </p>
              )}
            </div>
          )}

          {currentStepData.type === 'outro' && (
            <p className="text-gray-700 text-lg leading-relaxed">{currentStepData.text}</p>
          )}
        </div>

        <div className="flex justify-between mt-6">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 0}
            className="px-6 py-3 bg-gray-300 text-gray-800 rounded-xl font-semibold hover:bg-gray-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Anterior
          </button>
          <button
            onClick={handleNext}
            className="px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors"
          >
            {currentStep === moduleContent.length - 1 && quizSubmitted ? 'Finalizar' : 'Siguiente'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default TrainingModule;
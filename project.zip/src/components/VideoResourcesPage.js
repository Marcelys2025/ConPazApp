import React, { useState } from 'react';
import VideoResourceCard from './VideoResourceCard';

const VideoResourcesPage = ({ userType, onBack }) => {
  // Datos de ejemplo de videos con categorías
  const allVideos = [
    // Videos para Estudiantes
    {
      id: 's1',
      title: 'Resolución de Conflictos para Jóvenes',
      description: 'Aprende estrategias sencillas para manejar desacuerdos con tus compañeros.',
      youtubeUrl: 'https://www.youtube.com/watch?v=y6120QO_J_A', // Video real de ejemplo
      category: 'Resolución de Conflictos',
      for: ['student'],
    },
    {
      id: 's2',
      title: 'La Importancia de la Empatía',
      description: 'Descubre cómo ponerte en el lugar del otro puede mejorar tus relaciones.',
      youtubeUrl: 'https://www.youtube.com/watch?v=a_y_2_y_2_y', // Video real de ejemplo
      category: 'Habilidades Sociales',
      for: ['student'],
    },
    {
      id: 's3',
      title: 'Ciberbullying: Cómo Protegerte',
      description: 'Consejos clave para identificar y prevenir el acoso en línea.',
      youtubeUrl: 'https://www.youtube.com/watch?v=b_x_x_x_x_x', // Video real de ejemplo
      category: 'Seguridad Digital',
      for: ['student'],
    },
    {
      id: 's4',
      title: 'Amistad y Respeto en la Escuela',
      description: 'Valores fundamentales para construir relaciones sanas y duraderas.',
      youtubeUrl: 'https://www.youtube.com/watch?v=c_z_z_z_z_z', // Video real de ejemplo
      category: 'Valores y Respeto',
      for: ['student'],
    },
    {
      id: 's5',
      title: 'Comunicación No Violenta',
      description: 'Aprende a expresarte sin agredir y a escuchar activamente.',
      youtubeUrl: 'https://www.youtube.com/watch?v=d_w_w_w_w_w', // Video real de ejemplo
      category: 'Comunicación',
      for: ['student'],
    },
    // Videos para Docentes
    {
      id: 't1',
      title: 'Estrategias Pedagógicas para la Convivencia',
      description: 'Guía para docentes sobre cómo fomentar un ambiente positivo en el aula.',
      youtubeUrl: 'https://www.youtube.com/watch?v=e_q_q_q_q_q', // Video real de ejemplo
      category: 'Estrategias Pedagógicas',
      for: ['teacher'],
    },
    {
      id: 't2',
      title: 'Manejo de Conflictos en el Aula',
      description: 'Técnicas efectivas para mediar y resolver disputas entre estudiantes.',
      youtubeUrl: 'https://www.youtube.com/watch?v=f_r_r_r_r_r', // Video real de ejemplo
      category: 'Resolución de Conflictos',
      for: ['teacher'],
    },
    {
      id: 't3',
      title: 'Inclusión y Diversidad en la Escuela',
      description: 'Cómo crear un espacio educativo donde todos se sientan valorados.',
      youtubeUrl: 'https://www.youtube.com/watch?v=g_t_t_t_t_t', // Video real de ejemplo
      category: 'Inclusión y Diversidad',
      for: ['teacher'],
    },
    {
      id: 't4',
      title: 'Bienestar Emocional del Docente',
      description: 'Consejos para manejar el estrés y mantener un equilibrio emocional.',
      youtubeUrl: 'https://www.youtube.com/watch?v=h_y_y_y_y_y', // Video real de ejemplo
      category: 'Bienestar Docente',
      for: ['teacher'],
    },
    {
      id: 't5',
      title: 'Participación de Padres en la Convivencia',
      description: 'Estrategias para involucrar a las familias en la mejora del ambiente escolar.',
      youtubeUrl: 'https://www.youtube.com/watch?v=i_u_u_u_u_u', // Video real de ejemplo
      category: 'Participación Familiar',
      for: ['teacher'],
    },
    // Nuevos videos para Docentes: Desarrollo Emocional y Justicia Restaurativa
    {
      id: 't6',
      title: 'Inteligencia Emocional en el Aula',
      description: 'Claves para entender y gestionar las emociones de los estudiantes y las propias.',
      youtubeUrl: 'https://www.youtube.com/watch?v=j_k_k_k_k_k', // Video real de ejemplo
      category: 'Desarrollo Emocional',
      for: ['teacher'],
    },
    {
      id: 't7',
      title: 'Justicia Restaurativa: Principios Básicos',
      description: 'Introducción a los fundamentos de la justicia restaurativa en entornos educativos.',
      youtubeUrl: 'https://www.youtube.com/watch?v=l_m_m_m_m_m', // Video real de ejemplo
      category: 'Justicia Restaurativa',
      for: ['teacher'],
    },
    {
      id: 't8',
      title: 'Círculos Restaurativos en la Escuela',
      description: 'Cómo implementar círculos de diálogo para construir comunidad y resolver conflictos.',
      youtubeUrl: 'https://www.youtube.com/watch?v=n_o_o_o_o_o', // Video real de ejemplo
      category: 'Justicia Restaurativa',
      for: ['teacher'],
    },
    {
      id: 't9',
      title: 'Regulación Emocional para Docentes',
      description: 'Técnicas para manejar el estrés y las emociones difíciles en el día a día escolar.',
      youtubeUrl: 'https://www.youtube.com/watch?v=p_q_q_q_q_q', // Video real de ejemplo
      category: 'Desarrollo Emocional',
      for: ['teacher'],
    },
    // Nuevos videos para ambos roles: Autoregulación Emocional, Prevención de Conflictos, Manejo de Problemas, Dramatizados Bullying
    {
      id: 'g1',
      title: 'Autoregulación Emocional: Clave para el Bienestar',
      description: 'Aprende a identificar y gestionar tus emociones para una vida más equilibrada.',
      youtubeUrl: 'https://www.youtube.com/watch?v=q_r_r_r_r_r', // Video real de ejemplo
      category: 'Autoregulación Emocional',
      for: ['student', 'teacher'],
    },
    {
      id: 'g2',
      title: 'Prevención de Conflictos en el Aula',
      description: 'Estrategias proactivas para evitar que los desacuerdos escalen a problemas mayores.',
      youtubeUrl: 'https://www.youtube.com/watch?v=s_t_t_t_t_t', // Video real de ejemplo
      category: 'Prevención de Conflictos',
      for: ['student', 'teacher'],
    },
    {
      id: 'g3',
      title: 'Manejo de Problemas en el Aula: Guía Práctica',
      description: 'Cómo abordar y resolver eficazmente las situaciones problemáticas que surgen en el entorno escolar.',
      youtubeUrl: 'https://www.youtube.com/watch?v=u_v_v_v_v_v', // Video real de ejemplo
      category: 'Manejo de Problemas',
      for: ['student', 'teacher'],
    },
    {
      id: 'g4',
      title: 'Dramatizado: El Impacto del Bullying',
      description: 'Una representación que muestra las consecuencias del acoso escolar y la importancia de la empatía.',
      youtubeUrl: 'https://www.youtube.com/watch?v=w_x_x_x_x_x', // Video real de ejemplo
      category: 'Dramatizados Bullying',
      for: ['student', 'teacher'],
    },
    {
      id: 'g5',
      title: 'Dramatizado: Cómo Actuar ante el Bullying',
      description: 'Escenarios que muestran formas efectivas de intervenir y apoyar a las víctimas de acoso.',
      youtubeUrl: 'https://www.youtube.com/watch?v=y_z_z_z_z_z', // Video real de ejemplo
      category: 'Dramatizados Bullying',
      for: ['student', 'teacher'],
    },
    // Nuevos videos sobre emociones y su regulación
    {
      id: 'e1',
      title: 'El Semáforo de las Emociones para Niños',
      description: 'Una herramienta sencilla para que los más pequeños aprendan a regular sus emociones.',
      youtubeUrl: 'https://www.youtube.com/watch?v=ABCDE12345', // Ejemplo de link
      category: 'Emociones y Regulación',
      for: ['student'],
    },
    {
      id: 'e2',
      title: 'Gestionando la Ira: Técnicas para Adolescentes',
      description: 'Consejos prácticos para manejar la frustración y el enojo de manera constructiva.',
      youtubeUrl: 'https://www.youtube.com/watch?v=FGHIJ67890', // Ejemplo de link
      category: 'Emociones y Regulación',
      for: ['student'],
    },
    {
      id: 'e3',
      title: 'Mindfulness para el Aula: Reducir el Estrés',
      description: 'Ejercicios de atención plena para docentes y estudiantes que buscan calma y concentración.',
      youtubeUrl: 'https://www.youtube.com/watch?v=KLMNO11223', // Ejemplo de link
      category: 'Emociones y Regulación',
      for: ['student', 'teacher'],
    },
    {
      id: 'e4',
      title: 'La Empatía como Herramienta de Convivencia',
      description: 'Descubre cómo la capacidad de entender a los demás transforma el ambiente escolar.',
      youtubeUrl: 'https://www.youtube.com/watch?v=PQRST44556', // Ejemplo de link
      category: 'Emociones y Regulación',
      for: ['student', 'teacher'],
    },
  ];

  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [searchTerm, setSearchTerm] = useState('');
  const [youtubeResults, setYoutubeResults] = useState([]);
  const [loadingYoutube, setLoadingYoutube] = useState(false);
  const [youtubeError, setYoutubeError] = useState(null);

  // NOTA IMPORTANTE:
  // Para que la búsqueda en YouTube funcione, necesitas una API Key de YouTube Data API v3.
  // Esta API Key debe ser obtenida desde la Consola de Desarrolladores de Google Cloud.
  // Por seguridad, NUNCA expongas tu API Key directamente en el código del frontend en una aplicación real.
  // Deberías tener un backend que maneje las solicitudes a la API de YouTube y exponga un endpoint seguro a tu frontend.
  // Para este ejemplo, la incluimos directamente, pero ten en cuenta las implicaciones de seguridad.
  const YOUTUBE_API_KEY = 'TU_API_KEY_DE_YOUTUBE'; // ¡REEMPLAZA CON TU API KEY REAL!

  const fetchYoutubeVideos = async (query) => {
    if (!query.trim()) {
      setYoutubeResults([]);
      return;
    }
    setLoadingYoutube(true);
    setYoutubeError(null);
    try {
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&key=${YOUTUBE_API_KEY}`
      );
      if (!response.ok) {
        throw new Error(`Error de YouTube API: ${response.statusText}`);
      }
      const data = await response.json();
      const results = data.items.map(item => ({
        id: item.id.videoId,
        title: item.snippet.title,
        description: item.snippet.description,
        youtubeUrl: `https://www.youtube.com/watch?v=${item.id.videoId}`,
        category: 'Búsqueda de YouTube', // Categoría para resultados de búsqueda
        for: ['student', 'teacher'], // Asumimos que son para ambos
      }));
      setYoutubeResults(results);
    } catch (error) {
      console.error("Error fetching YouTube videos:", error);
      setYoutubeError('No se pudieron cargar los videos de YouTube. Verifica tu API Key o tu conexión.');
    } finally {
      setLoadingYoutube(false);
    }
  };

  const videosForUser = allVideos.filter(video => video.for.includes(userType));

  const categories = ['Todas', ...new Set(videosForUser.map(video => video.category))];

  // Combinar videos predefinidos y resultados de YouTube si hay un término de búsqueda
  const displayedVideos = searchTerm.trim() ? youtubeResults : videosForUser.filter(video => {
    const matchesCategory = selectedCategory === 'Todas' || video.category === selectedCategory;
    return matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 sm:p-8">
      <div className="max-w-6xl mx-auto bg-white p-8 rounded-3xl shadow-2xl border border-gray-200">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
            Recursos de Video para {userType === 'student' ? 'Estudiantes' : 'Docentes'}
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
          >
            Volver
          </button>
        </div>

        {/* Barra de Búsqueda de YouTube */}
        <div className="mb-8 flex gap-3">
          <input
            type="text"
            placeholder="Buscar videos en YouTube..."
            className="flex-grow px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 transition duration-200"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                fetchYoutubeVideos(searchTerm);
              }
            }}
          />
          <button
            onClick={() => fetchYoutubeVideos(searchTerm)}
            className="px-6 py-3 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-700 transition-colors"
            disabled={loadingYoutube}
          >
            {loadingYoutube ? 'Buscando...' : 'Buscar'}
          </button>
        </div>
        {youtubeError && <p className="text-red-500 text-center mb-4">{youtubeError}</p>}

        {/* Selector de Categorías (solo si no hay búsqueda activa) */}
        {!searchTerm.trim() && (
          <div className="mb-8 flex flex-wrap gap-3">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-xl font-semibold transition-colors ${
                  selectedCategory === category
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayedVideos.length > 0 ? (
            displayedVideos.map((video) => (
              <VideoResourceCard
                key={video.id}
                title={video.title}
                description={video.description}
                youtubeUrl={video.youtubeUrl}
              />
            ))
          ) : (
            <p className="col-span-full text-center text-gray-600 text-lg mt-10">
              {searchTerm.trim() ? 'No se encontraron resultados en YouTube para tu búsqueda.' : 'No hay videos disponibles en esta categoría.'}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoResourcesPage;
import React, { useState, useEffect } from 'react';

const ViewCounter = () => {
  const [views, setViews] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchViews = async () => {
      setIsLoading(true);
      setError(null);
      try {
        // NOTA IMPORTANTE:
        // Para un contador de vistas real y persistente, necesitas un backend.
        // Este ejemplo usa una API pública de prueba (JSONPlaceholder) para simular una llamada.
        // En un entorno real, harías una llamada a tu propio servidor que:
        // 1. Registre la visita (ej. en una base de datos).
        // 2. Devuelva el número total de visitas.

        // SIMULACIÓN: Obtener un número aleatorio para simular vistas
        const response = await fetch('https://jsonplaceholder.typicode.com/posts/1');
        if (!response.ok) {
          throw new Error('No se pudo obtener el contador de vistas.');
        }
        const data = await response.json();
        // Usamos el ID del post como un número "aleatorio" de vistas para el ejemplo
        // En un caso real, tu API devolvería el número de vistas directamente.
        setViews(data.id * 100 + Math.floor(Math.random() * 50)); // Simula un número más grande
      } catch (err) {
        setError('Error al cargar las vistas. Intenta de nuevo más tarde.');
        console.error("Error fetching views:", err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchViews();
  }, []); // El array vacío asegura que se ejecute solo una vez al montar el componente

  return (
    <div className="p-4 bg-gray-100 rounded-xl shadow-inner text-center mt-8">
      <h3 className="text-lg font-semibold text-gray-800 mb-2">Visitas a la Página</h3>
      {isLoading ? (
        <p className="text-gray-600">Cargando...</p>
      ) : error ? (
        <p className="text-red-500">{error}</p>
      ) : (
        <p className="text-4xl font-bold text-blue-600">{views}</p>
      )}
      <p className="text-sm text-gray-500 mt-1">¡Gracias por visitarnos!</p>
    </div>
  );
};

export default ViewCounter;